<?php
/**
 * Load and register widgets
 *
 * @package Clerina
 */

require_once CLERINA_ADDONS_DIR . '/inc/widgets/popular-posts.php';
require_once CLERINA_ADDONS_DIR . '/inc/widgets/service-category.php';
require_once CLERINA_ADDONS_DIR . '/inc/widgets/social-media-links.php';

/**
 * Register widgets
 *
 * @since  1.0
 *
 * @return void
 */
if ( ! function_exists( 'clerina_register_widgets' ) ) {

	function clerina_register_widgets() {
		register_widget( 'Clerina_PopularPost_Widget' );
		register_widget( 'Clerina_Service_Category_Widget' );
		register_widget( 'Clerina_Social_Links_Widget' );


	}

	add_action( 'widgets_init', 'clerina_register_widgets' );
}