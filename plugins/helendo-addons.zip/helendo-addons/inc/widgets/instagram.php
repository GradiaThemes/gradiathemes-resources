<?php

if ( ! class_exists( 'Helendo_Instagram_Widget' ) ) {
	class Helendo_Instagram_Widget extends WP_Widget {
		/**
		 * Holds widget settings defaults, populated in constructor.
		 *
		 * @var array
		 */
		protected $default;

		/**
		 * List of supported instagram
		 *
		 * @var array
		 */
		protected $socials;

		/**
		 * Constructor
		 */
		function __construct() {
			$this->default = array(
				'title'        => esc_html__( 'Instagram', 'helendo' ),
				'number'       => 6,
				'orginal_size' => 1,
				'target'       => '_self',
			);

			parent::__construct(
				'helendo-instagram-widget',
				esc_html__( 'Helendo - Instagram', 'helendo' ),
				array(
					'classname'                   => 'helendo-instagram-widget',
					'description'                 => esc_html__( 'Displays your latest Instagram photos.', 'helendo' ),
					'customize_selective_refresh' => true
				),
				array( 'width' => 600 )
			);
		}

		/**
		 * Outputs the HTML for this widget.
		 *
		 * @param array $args An array of standard parameters for widgets in this theme
		 * @param array $instance An array of settings for this widget instance
		 *
		 * @return void Echoes it's output
		 */
		function widget( $args, $instance ) {
			$instance = wp_parse_args( $instance, $this->default );

			$title   = empty( $instance['title'] ) ? '' : apply_filters( 'widget_title', $instance['title'] );
			$limit   = empty( $instance['number'] ) ? 3 : $instance['number'];
			$target  = empty( $instance['target'] ) ? '_self' : $instance['target'];
			$medias  = $this->helendo_get_instagram_images( $limit );
			$current = 1;

			echo wp_kses_post( $args['before_widget'] );

			if ( ! empty( $title ) ) {
				echo wp_kses_post( $args['before_title'] ) . wp_kses_post( $title ) . wp_kses_post( $args['after_title'] );
			};

			$size = intval( $instance['orginal_size'] ) ? 'original' : 'cropped';

			echo '<div class="instagram-feed instagram-feed--' . esc_attr( $size ) . '">';
			echo '<ul class="row-flex instagram-pics">';

			foreach ( $medias as $media ) {
				if ( $current > $limit ) {
					break;
				}

				$this->helendo_instagram_image( $media, $instance['orginal_size'], $target );

				$current++;
			}

			echo '</ul>';
			echo '</div>';

			echo wp_kses_post( $args['after_widget'] );
		}

		/**
		 * Update widget
		 *
		 * @param array $new_instance New widget settings
		 * @param array $old_instance Old widget settings
		 *
		 * @return array
		 */
		function update( $new_instance, $old_instance ) {
			$new_instance['title']        = strip_tags( $new_instance['title'] );
			$new_instance['number']       = ! absint( $new_instance['number'] ) ? 6 : $new_instance['number'];
			$new_instance['target']       = ( ( '_self' === $new_instance['target'] || '_blank' === $new_instance['target'] ) ? $new_instance['target'] : '_self' );
			$new_instance['orginal_size'] = ! empty( $new_instance['orginal_size'] );
			
			return $new_instance;
		}

		/**
		 * Displays the form for this widget on the Widgets page of the WP Admin area.
		 *
		 * @param array $instance
		 *
		 * @return string|void
		 */
		function form( $instance ) {
			$instance = wp_parse_args( $instance, $this->default );
			$title    = $instance['title'];
			$number   = absint( $instance['number'] );
			$target   = $instance['target'];
			?>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'helendo' ); ?>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"
                           name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text"
                           value="<?php echo esc_attr( $title ); ?>"/></label>
            </p>
           
            <p>
                <label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number of photos', 'helendo' ); ?>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"
                           name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="text"
                           value="<?php echo esc_attr( $number ); ?>"/></label>
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_id( 'target' ) ); ?>"><?php esc_html_e( 'Open links in', 'helendo' ); ?></label>
                <select id="<?php echo esc_attr( $this->get_field_id( 'target' ) ); ?>"
                        name="<?php echo esc_attr( $this->get_field_name( 'target' ) ); ?>" class="widefat">
                    <option value="_self" <?php selected( '_self', $target ); ?>><?php esc_html_e( 'Current window (_self)', 'helendo' ); ?></option>
                    <option value="_blank" <?php selected( '_blank', $target ); ?>><?php esc_html_e( 'New window (_blank)', 'helendo' ); ?></option>
                </select>
			</p>
			<p>
				<input id="<?php echo esc_attr( $this->get_field_id( 'orginal_size' ) ); ?>"
					name="<?php echo esc_attr( $this->get_field_name( 'orginal_size' ) ); ?>" type="checkbox"
					value="1" <?php checked( $instance['orginal_size'] ); ?>>
				<label for="<?php echo esc_attr( $this->get_field_id( 'orginal_size' ) ); ?>"><?php esc_html_e( 'Use Original Image Size', 'helendo' ); ?></label>
			</p>
			<?php
		}

		/**
		 * Display a single Instagram photo
		 */
		protected function helendo_instagram_image( $media, $orginal_size, $target ) {
			if ( ! is_array( $media ) ) {
				return;
			}

			$srcset = array(
				$media['images']['thumbnail'] . ' 320w',
				$media['images']['original'] . ' 640w',
				$media['images']['original'] . ' 2x',
			);
			$sizes  = array(
				'(max-width: 1400px) 320px',
				'320px',
			);
			$caption = is_array( $media['caption'] ) && isset( $media['caption']['text'] ) ? $media['caption']['text'] : $media['caption'];

			$image  = sprintf(
				'<img src="%s" alt="%s" srcset="%s" sizes="%s">',
				esc_url( $media['images']['thumbnail'] ),
				esc_attr( $caption ),
				esc_attr( implode( ', ', $srcset ) ),
				esc_attr( implode( ', ', $sizes ) )
			);

			$style = '';

			if ( ! intval( $orginal_size ) ) {
				$style = 'style="background-image: url(' . esc_url( $media['images']['thumbnail'] ) . ')"';
			}

			printf(
				'<li><a href="%s" target="%s" rel="nofollow" %s>%s</a></li>',
				esc_url( $media['link'] ),
				esc_attr($target),
				$style,
				$image
			);
		}

		/**
		 * Get Instagram images
		 *
		 * @param int $limit
		 *
		 * @return array|WP_Error
		 */
		protected function helendo_get_instagram_images( $limit = 12 ) {
			$access_token = get_theme_mod( 'api_instagram_token' );

			if ( empty( $access_token ) ) {
				return new WP_Error( 'instagram_no_access_token', esc_html__( 'No access token', 'helendo' ) );
			}

			$user = $this->helendo_get_instagram_user();

			if ( ! $user || is_wp_error( $user ) ) {
				return $user;
			}

			$transient_key = 'helendo_instagram_photos_' . sanitize_title_with_dashes( $user['username'] . '__' . $limit );
			$images = get_transient( $transient_key );

			if ( false === $images || empty( $images ) ) {
				$images = array();
				$next = false;

				while ( count( $images ) < $limit ) {
					if ( ! $next ) {
						$fetched = $this->helendo_fetch_instagram_media( $access_token );
					} else {
						$fetched = $this->helendo_fetch_instagram_media( $next );
					}

					if ( is_wp_error( $fetched ) ) {
						break;
					}

					$images = array_merge( $images, $fetched['images'] );
					$next = $fetched['paging']['cursors']['after'];
				}

				if ( ! empty( $images ) ) {
					set_transient( $transient_key, $images, 2 * 3600 ); // Cache for 2 hours.
				}
			}

			if ( ! empty( $images ) ) {
				return $images;
			} else {
				return new WP_Error( 'instagram_no_images', esc_html__( 'Instagram did not return any images.', 'helendo' ) );
			}
		}

		/**
		 * Fetch photos from Instagram API
		 *
		 * @param  string $access_token
		 * @return array
		 */
		protected function helendo_fetch_instagram_media( $access_token ) {
			$url = add_query_arg( array(
				'fields'       => 'id,caption,media_type,media_url,permalink,thumbnail_url',
				'access_token' => $access_token,
			), 'https://graph.instagram.com/me/media' );

			$remote = wp_remote_retrieve_body( wp_remote_get( $url ) );
			$data   = json_decode( $remote, true );
			$images = array();

			if ( isset( $data['error'] ) ) {
				return new WP_Error( 'instagram_error', $data['error']['message'] );
			} else {
				foreach ( $data['data'] as $media ) {
					$images[] = array(
						'type'    => $media['media_type'],
						'caption' => isset( $media['caption'] ) ? $media['caption'] : $media['id'],
						'link'    => $media['permalink'],
						'images'  => array(
							'thumbnail' => ! empty( $media['thumbnail_url'] ) ? $media['thumbnail_url'] : $media['media_url'],
							'original'  => $media['media_url'],
						),
					);
				}
			}

			return array(
				'images' => $images,
				'paging' => $data['paging'],
			);
		}

		/**
		 * Get user data
		 *
		 * @return bool|WP_Error|array
		 */
		protected function helendo_get_instagram_user() {
			$access_token = get_theme_mod( 'api_instagram_token' );

			if ( empty( $access_token ) ) {
				return new WP_Error( 'no_access_token', esc_html__( 'No access token', 'helendo' ) );
			}

			$transient_key = 'helendo_instagram_user_' . $access_token;

			$user = get_transient( $transient_key );

			if ( false === $user ) {
				$url  = add_query_arg( array( 'fields' => 'id,username', 'access_token' => $access_token ), 'https://graph.instagram.com/me' );
				$data = wp_remote_get( $url );
				$data = wp_remote_retrieve_body( $data );

				if ( ! $data ) {
					return new WP_Error( 'no_user_data', esc_html__( 'No user data received', 'helendo' ) );
				}

				$user = json_decode( $data, true );

				if ( ! empty( $data ) ) {
					set_transient( $transient_key, $user, 2592000 ); // Cache for one month.
				}
			}

			return $user;
		}
	}
}