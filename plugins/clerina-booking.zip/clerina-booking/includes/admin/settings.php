<?php
class Clerina_Booking_Settings {
	public static function settings_page() {

	}

	/**
	 * Save settings.
	 */
	public static function save() {

	}
}
