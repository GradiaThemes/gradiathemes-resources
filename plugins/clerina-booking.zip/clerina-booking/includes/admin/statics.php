<?php
class Clerina_Booking_Statics {
	public static function statics_page() {

	}
}
